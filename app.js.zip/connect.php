<?php
// Database configuration
$hostname = 'localhost'; // Change to your database host
$username = 'rwanxypu_parking_1'; // Change to your database username
$password = '+]m[RP}yWiQP'; // Change to your database password
$database = 'rwanxypu_parking'; // Change to your database name

try {
    $db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // echo "Connected successfully";
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
