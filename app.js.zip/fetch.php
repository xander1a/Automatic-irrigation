<?php
require 'connect.php';

// Use a SELECT statement to retrieve the last inserted record
$sql = "SELECT * FROM irrigation ORDER BY id DESC LIMIT 1";
$stmt = $db->prepare($sql);
$stmt->execute();

// Fetch the data
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    // Print the retrieved data
    //print_r($result);
} else {
    echo "No data found.";
}
//echo $result['ph'];
?>


<!--<div class="bg-white p-4 shadow rounded-lg">-->
<!--    <h2 class="text-xl font-semibold mb-2">Latitude</h2>-->
   
       
        
<!-- <?php echo $result['water']; ?>-->


<!--</div>-->


<div class="justify-center container pb-8 p-4 border-2 border-gray-400 rounded my-11 ">
    <h1 class="text-3xl font-bold mb-4 text-center">Automatic Irrigation Dashboard</h1>

    <div class="grid grid-cols-2 gap-4 flex  items-center">
        <!-- Pump Status -->
        <div class="p-4 bg-white rounded shadow dark:bg-gray-800">
            <h2 class="text-xl font-semibold mb-2 text-center">Pump Status</h2>
            <p id="pumpStatus" class="text-2xl text-green-500 text-center"><?php echo $result['pump']; ?></p>
        </div>
        <!-- Soil Moisture -->
        <div class="p-4 bg-white rounded shadow dark:bg-gray-800">
            <h2 class="text-xl font-semibold mb-2 text-center">Soil Moisture</h2>
<p id="soilMoisture" class="text-2xl text-blue-500 text-center">
    <?php echo intval($result['value'] * 100 / 1020); ?>%
</p>


        </div>
        <!-- Soil Condition -->
        <div class="p-4 bg-white rounded shadow dark:bg-gray-800 col-span-2">
            <h2 class="text-xl font-semibold mb-2 text-center">Current Soil Value</h2>
            <p id="soilCondition" class="text-2xl text-yellow-500 text-center"><?php echo $result['value']; ?></p>
        </div>
    </div>

    <div class="fixed bottom-4 right-4">
     <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 bg-gray-100 text-white rounded-full focus:outline-none">
        <span x-show="!darkMode">🌞</span>
        <span x-show="darkMode">🌙</span>
    </button>
    <a href="index.html" class="button-like-link">Logout</a>


</div>

</div>
