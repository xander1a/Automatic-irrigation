<?php

// Enable error reporting during development
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'connect.php';

// Initialize the response array
$response = array();

// Get the received JSON data from the POST request
$receivedData = file_get_contents('php://input');
file_put_contents('received_data.log', $receivedData);

// Decode the received JSON data into a PHP array
$data = json_decode($receivedData, true);

// Check if the request is a POST request and if it contains JSON data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($receivedData)) {
    // Check if the required keys 'sendval' and 'sendval2' exist in the JSON data
    if (isset($data['sendval']) && isset($data['sendval2'])) {
        // Extract and sanitize the values
        $val2 = $data['sendval'];
        $val3 = $data['sendval2'];

        // Check if both values are not zero before proceeding with the insertion
        if ($val2 !== 0 ) {
            // Assuming you have an active database connection in $db
            try {
                $sql = "INSERT INTO irrigation (pump, value) VALUES (:val3, :val2)";
                $stmt = $db->prepare($sql);
                $stmt->bindParam(':val2', $val2);
                $stmt->bindParam(':val3', $val3);

                // Execute the SQL statement
                if ($stmt->execute()) {
                    $response['success'] = true;
                    $response['message'] = "Data inserted successfully.";
                } else {
                    $response['success'] = false;
                    $response['message'] = "Error inserting data: " . $stmt->errorInfo()[2];
                }
            } catch (PDOException $e) {
                $response['success'] = false;
                $response['message'] = "Database error: " . $e->getMessage();
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Values cannot be zero.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Missing required keys in JSON data.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request or missing JSON data.";
}

// Close the database connection
$db = null;

// Return a JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
