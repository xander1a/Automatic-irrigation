<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automatic Irrigation Dashboard</title>
    <!-- Add Tailwind CSS styles -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Custom styles for dark mode -->
    <style>
        .dark-mode body {
            background-color: #1a202c;
            color: #cbd5e0;
        }

        .dark-mode .bg-white {
            background-color: red;
            color: #cbd5e0;
        }
        .button-like-link {
    display: inline-block;
    padding: 10px 20px;
    background-color: #3498db;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
  }

  .button-like-link:hover {
    background-color: #2980b9;
  }
    </style>
</head>
<body x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }" :class="{ 'dark-mode': darkMode }" class="bg-gray-100 transition-colors duration-300">

<div id="refreshDiv">
                    <!-- Your content goes here -->
 </div>
<!-- Dark Mode Toggle -->

<!-- Add Alpine.js for dynamic behavior -->
<script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>





<script>
function refreshDivContent() {
    var refreshDiv = document.getElementById('refreshDiv');
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            refreshDiv.innerHTML = xhr.responseText;
        }
    };

    xhr.open('GET', 'fetch.php', true); // Replace 'refresh_content.php' with your server-side script
    xhr.send();
}

// Refresh the div content every 5 seconds (5000 milliseconds)
setInterval(refreshDivContent, 1000);
</script>
</body>
</html>
